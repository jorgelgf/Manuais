import type { NextPage } from "next";

const Home: NextPage = () => {
  return (
    <div>
      <div>Meu teste</div>
    </div>
  );
};

export default Home;
