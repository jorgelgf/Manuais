function saudacao(nome) {
  return (req, res, next) => {
    console.log("bem vindo " + nome);
    next();
  };
}

module.exports = saudacao;
