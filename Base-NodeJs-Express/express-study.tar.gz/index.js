const express = require("express");
const saudacao = require("./saudacao");
const bodyParser = require("body-parser");
const app = express();
const usuarioApi = require("./api/usuario");

require("./api/produto")(app, "Celular");

app.use(bodyParser.json());
app.use(saudacao("jorge"));
app.use(bodyParser.urlencoded({ extended: true }));

app.get("/usuario", usuarioApi.obter);

app.post("/usuario", usuarioApi.salvar);

app.post("/corpo", (req, res) => {
  res.send(req.body);
});

app.get("/test", (req, res) => {
  res.json({ nome: "jorge" });
});

app.get("/clientes/relatorio", (req, res, next) => {
  res.send(
    `Cliente relatório completo: ${req.query.completo}, ano: ${req.query.ano}`
  );
});

app.get("/clientes/:id", (req, res, next) => {
  res.send(`Cliente: ${req.params.id} foi selecionado`);
});

app.listen(3001, () => {
  console.log("backend executando");
});
