function App() {
  return <div className="App">teste</div>;
}

export default App;
